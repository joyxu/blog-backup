var JSLauncher = JSLauncher || {};

JSLauncher.App = function() {
	forward.app.call(this);

	this.mainlayer;
	this.menulist;
	this.menuroot = new JSLauncher.MenuData({});
};

forward.utility.extend(JSLauncher.App, forward.app);

JSLauncher.App.prototype.Exec = function() {
	JSLauncher.App.uber.Exec.call(this);
	
	this._createLayer();
	this._createMainMenu();
	this.mainlayer.SetActiveControl(this.menulist.GetMenuControl().GetID());	
	
};

JSLauncher.App.prototype._createLayer = function() {
	this.mainlayer = new forward.ui.Layer({layerID: "home"});
	$(forward.ui.message).trigger(forward.ui.define.MESSAGE.LAYER.ACTIVATE, ["home"]);
};

JSLauncher.App.prototype._createMainMenu = function() {
		
	var mainmenu = {
			menu1:{
				title:"本地媒体",
				icon:"css/img/media.png",
				submenus:{
					menu1:
					{
						title:"视频",
					},
					menu2:
					{
						title:"音频",
					},
					menu3:
					{
						title:"图片",
					},
				},
			},
			menu2:{
				title:"浏览器",
				icon:"css/img/browser.png",
			},
			menu3:{
				title:"网络媒体",
				icon:"css/img/netmedia.png",
				submenus:{
					menu1:
					{
						title:"优库",
					},
					menu2:
					{
						title:"土豆",
					},
					menu3:
					{
						title:"酷6",
					},
					menu4:
					{
						title:"56网",
					},
					menu5:
					{
						title:"爱奇艺",
					},
					menu6:
					{
						title:"乐视网",
					},
					menu7:
					{
						title:"激动网",
					},
					menu8:
					{
						title:"新浪视频",
					},
					menu9:
					{
						title:"搜狐视频",
					},					
					menu10:
					{
						title:"网易视频",
					},
					menu11:
					{
						title:"凤凰视频",
					},					
					menu12:
					{
						title:"腾讯视频",
					},						
				},				
			},
			menu4:{
				title:"设置",
				icon:"css/img/settings.png",
			},
			menu5:{
				title:"应用",
				icon:"css/img/androidtv.png",
			},			
	};
		
	for ( var menuitem in mainmenu) {
		var menudataparam = {};
		menudataparam.title = mainmenu[menuitem].title;
		menudataparam.icon = mainmenu[menuitem].icon;
		menudataparam.depth = 1;
		var parentmenu = new JSLauncher.MenuData(menudataparam);
		if( null != mainmenu[menuitem].submenus ){
			for ( var submenuitem in mainmenu[menuitem].submenus) {
				menudataparam.title = mainmenu[menuitem].submenus[submenuitem].title;
				menudataparam.icon = mainmenu[menuitem].submenus[submenuitem].icon;
				menudataparam.depth = 2;
				var submenu = new JSLauncher.MenuData(menudataparam);
				parentmenu.AddMenuData(submenu);
			}
		}
		this.menuroot.AddMenuData(parentmenu);
	}
	
	var jslauncher = this;
	
	var param = {
		controlID: "mainmenu",
		style: {
			container: "mainmenu_container",
			itemParent: "mainmenu_item_parent",
			item: "mainmenu_item",
		},
		layer: this.mainlayer,
		menudata : this.menuroot,
		move :function(menuparam) {
			jslauncher.ChangeFoucus(menuparam);
		},	
	};
	this.menulist = new JSLauncher.Menu(param);
	this.menulist.Create();
	if( null != window.JSBridge){
		window.JSBridge.updateApp();
	}
};

JSLauncher.App.prototype.ChangeFoucus = function(menuparam) {
	
//	$("#mainicon").text(menuparam.title);
	if( "" !=  menuparam.icon){
//		$("#mainicon").css("background" , "url(" + menuparam.icon + ")" );
		$("#mainicon").fadeOut("fast", function(){
			if( menuparam.icon.indexOf("css/img") != -1){
				$("#mainicon").css("background" , "url(" + menuparam.icon + ")" );
			}else{
				$("#mainicon").css("background" , "url("+ "data:image/jpeg;base64," + menuparam.icon + ")" + " no-repeat center ");
			}
			$("#mainicon").fadeIn("fast");
		});		
	}
};

JSLauncher.App.prototype.ResetApplication = function(param) {
	var appparentmenu = this.menuroot.GetMenuByTitle("应用");
	appparentmenu.ClearSubmenu();
	var paramarray = eval(param);
	for(var index = 0 ; index < paramarray.length ; index++){		
		var menudataparam = {};
		menudataparam.title = paramarray[index].title;
		menudataparam.icon = paramarray[index].icon;
		menudataparam.data = paramarray[index].intent;
		menudataparam.depth = 2;
		appparentmenu.AddMenuData(new JSLauncher.MenuData(menudataparam));		
	}
	if(null != this.menulist.GetSubMenuByTitle("应用")){
		this.menulist.GetSubMenuByTitle("应用").UpdateByMenuData();	
	}else{
		var jslauncher = this;
		var param = {
				controlID: "jsmenu14",
				style: {
					container: "submenu_container",
					itemParent: "submenu_item_parent",
					item: "submenu_item",
				},
				layer: this.mainlayer,
				menudata : appparentmenu,
				move :function(menuparam) {
					jslauncher.ChangeFoucus(menuparam);
				},	
		};		
		var tmpsubmenu = new JSLauncher.Menu(param)
		this.menulist.AddSubMenu("应用",tmpsubmenu);
		tmpsubmenu.Create();
	}
};

	