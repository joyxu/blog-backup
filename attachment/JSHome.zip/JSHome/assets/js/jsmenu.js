//menudata
JSLauncher.MenuData = function(param){
	this.title = param.title || "";
	this.icon = param.icon || "";
	this.data = param.data || null ;
	this.click = param.click || null;
	this.submenus = [];
	this.depth = param.depth || 0;
};

JSLauncher.MenuData.prototype.AddMenuData = function(menudata) {
	this.submenus.push(menudata);
};

JSLauncher.MenuData.prototype.GetDepth = function() {
	return this.depth;
};

JSLauncher.MenuData.prototype.GetTitle = function() {
	return this.title;
};

JSLauncher.MenuData.prototype.GetSubMenuCount = function() {
	return this.submenus.length;
};

JSLauncher.MenuData.prototype.GetSubMenuByIndex = function(index) {
	if(index < 0 || index >= this.submenus.length){
		return null;
	}
	return this.submenus[index];
};

JSLauncher.MenuData.prototype.GetMenuIcon = function() {
	return this.icon;
};

JSLauncher.MenuData.prototype.GetMenuByTitle = function(param) {
	if( this.title == param ){
		return this;
	}else{
		if(this.submenus.length == 0){
			return null;
		}else{
			for(var index = 0 ; index < this.submenus.length; index++){
				var result = this.submenus[index].GetMenuByTitle(param);
				if(result != null){
					return result;
				}
			}	
		}		
	}
};

JSLauncher.MenuData.prototype.ClearSubmenu = function() {
	this.submenus.length = 0;
}

//menu
JSLauncher.Menu = function(param) {
	
	this.menudata = param.menudata || null;
	this.layer = param.layer || null ;
	this.controlID = param.controlID || null;
	this.style = param.style || {};
	this.move = param.move || null;
	this.submenu = {};
	
	this.navigationTable = {};
		
	var tmporientation = forward.ui.define.ORIENTATION.HORIZONTAL;
	this.layer.controlNavigateMappingTable[this.controlID] = [this.controlID, this.controlID, this.controlID, this.controlID];	
	if( this.menudata.GetDepth() != 0 ){
		tmporientation = forward.ui.define.ORIENTATION.VERTICAL;
		this.layer.controlNavigateMappingTable[this.controlID] = ["mainmenu", "mainmenu", "mainmenu", this.controlID];		
		var tmpstyle = {
			container: "submenu_container",
			itemParent: "submenu_item_parent",
			item: "submenu_item",
			highlight: "submenu_item_highlight",
		};
		this.style = tmpstyle;
	}
	
	var menumanager = this;
	
	var listparam = {
			controlID: this.controlID,
			style: this.style,
			orientation : tmporientation,
//			listSize: this.menudata.GetSubMenuCount(),
			listSize: 7,
			down: function() {
				menumanager.ResetNavTableOnDown();
			},	
			left: function() {
				if(menumanager.GetMenuControl().GetSelectItem() == 0){
					return;
				}				
				menumanager.ShowSubMenu(false);
			},	
			right: function() {
				if(menumanager.GetMenuControl().GetSelectItem() >= menumanager.GetMenuControl()._getItemCount() -1 ){
					return;
				}
				menumanager.ShowSubMenu(false);
			},			
			move:function() {
				menumanager.Move();
			},	
	};
	
	this.selfmenu = new forward.ui.List(listparam);
	this.layer.AddControl(this.selfmenu);
	
	
	if( this.menudata.GetSubMenuCount() != 0  ){
		for(var index = 0 ; index < this.menudata.GetSubMenuCount() ; index++){
			if(this.menudata.GetSubMenuByIndex(index).GetSubMenuCount() != 0){
				var tmpparam = {};
				forward.utility.copy(tmpparam , param);
				tmpparam.menudata = this.menudata.GetSubMenuByIndex(index);
				if(tmpparam.controlID.indexOf("jsmenu") != -1 ){
					tmpparam.controlID = tmpparam.controlID + tmpparam.menudata.GetDepth() + index;
				}else{
					tmpparam.controlID = "jsmenu" + tmpparam.menudata.GetDepth() + index;
				}
				this.submenu[tmpparam.menudata.GetTitle()] = new JSLauncher.Menu(tmpparam);
			}
		}
	}
};

JSLauncher.Menu.prototype.ResetNavTableOnDown = function() {
	if(this.menudata.GetDepth() == 0 ){
		var foucsitemindex = this.selfmenu.highlightItemIndex;
		if( this.menudata.GetSubMenuByIndex(foucsitemindex).GetSubMenuCount() != 0 ){
			this.layer.controlNavigateMappingTable[this.controlID] = [this.controlID, this.controlID, this.controlID, "jsmenu1" + this.selfmenu.highlightItemIndex];	
		}else{
			this.layer.controlNavigateMappingTable[this.controlID] = [this.controlID, this.controlID, this.controlID, this.controlID];	
		}
	}
};

JSLauncher.Menu.prototype.ShowSubMenu = function(flag) {
	var foucsitemindex = this.selfmenu.highlightItemIndex;
	if( this.menudata.GetDepth() == 0 && this.menudata.GetSubMenuByIndex(foucsitemindex).GetSubMenuCount() != 0 ){
		if(true == flag){
//			$("#" + "jsmenu1" + foucsitemindex + " > div").stop(true, true).slideDown("normal");
			$("#" + "jsmenu1" + foucsitemindex + " > div").show();
		}else{
//			$("#" + "jsmenu1" + foucsitemindex + " > div").stop(true, true).slideUp("normal");
			$("#" + "jsmenu1" + foucsitemindex + " > div").hide();
		}
	}
};

JSLauncher.Menu.prototype.Move = function() {
	var foucsitemindex = this.selfmenu.highlightItemIndex;
	this.ShowSubMenu(true);
	if(this.move != null){
		this.move(this.menudata.GetSubMenuByIndex(foucsitemindex));
	}
};

JSLauncher.Menu.prototype.Click = function() {
	var foucsitemindex = this.selfmenu.highlightItemIndex;
	var name = this.menudata.GetSubMenuByIndex(foucsitemindex).GetTitle();
	if( null != window.JSBridge){
		window.JSBridge.startApp(name);
	}
};

JSLauncher.Menu.prototype.GetControlID = function() {
	return this.controlID;
};

JSLauncher.Menu.prototype.GetSubMenuByTitle = function(title) {
	if(this.submenu[title] != null){
		return this.submenu[title];
	}
	return null;
};

JSLauncher.Menu.prototype.AddSubMenu = function(title , menu) {
	this.submenu[title] = menu;
};

JSLauncher.Menu.prototype.DelSubMenuByTitle = function(title) {
	if(this.submenu[title] != null){
		delete this.submenu[title];
	}
};

JSLauncher.Menu.prototype.GetMenuControl = function() {
	return this.selfmenu;
};

JSLauncher.Menu.prototype.GetSubMenuCount = function() {
	var count = 0 ;
	for ( var element in this.submenu) {
		count++;
	}
	return count;
};

JSLauncher.Menu.prototype.GetSubMenuByIndex = function(index) {
	var count = 0 ;
	for ( var element in this.submenu) {
		if(count == index){
			return this.submenu[element];
		}
		count++;
	}
	return null;
};

JSLauncher.Menu.prototype.Create = function() {
	var menumanager = this;
	for ( var i=0; i< this.menudata.GetSubMenuCount(); i++ ) {
		var submenudata = this.menudata.GetSubMenuByIndex(i);
		var itemParam = {
				div: "<div id=jsmenu" + submenudata.GetDepth() + i + ">" + submenudata.GetTitle() + "</div>",
				style: {
					highlight: "mainmenu_item_highlight",
				},
				click:function() {
					menumanager.Click();
				},	
		};
		
		if( this.menudata.GetDepth() != 0 ){
			var tmpstyle = {
					highlight: "submenu_item_highlight",
				};
			itemParam.style = tmpstyle;			
		}
		var item = new forward.ui.Item(itemParam);
		this.selfmenu.AddItem(item);
	}

	this.selfmenu.Create();

	//hide list
	if(this.menudata.GetDepth()!=0){
		$("#" + this.controlID + " > div").hide();
	}	
	
	for ( var element in this.submenu) {
		this.submenu[element].Create();
	}	
	
	this.ShowSubMenu(true);
	
};

JSLauncher.Menu.prototype.UpdateByMenuData = function(){
	this.selfmenu.DeleteAllItem();
	this.Create();
}