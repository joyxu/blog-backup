package com.joyx;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Gallery;

public class JSHomeActivity extends Activity {
	
	private static ArrayList<ApplicationInfo> mApplications;
	private final BroadcastReceiver mApplicationsReceiver = new ApplicationsIntentReceiver();
	private WebView mWebView = null;
	private Handler mJSBridgeHandler = new Handler();
	private JavaScriptInterface mJSInterface = null;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        registerIntentReceivers();
        loadApplications(true);           
		
        mWebView = (WebView) findViewById(R.id.webView1);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        mWebView.setClickable(true);  
        mWebView.setLongClickable(false);
        mWebView.setVerticalScrollBarEnabled(false);
        mWebView.setHorizontalScrollBarEnabled(false);
        mWebView.setWebViewClient(new JSHomeWebViewClient());
        
        mJSInterface = new JavaScriptInterface(this , mJSBridgeHandler);
        mWebView.addJavascriptInterface( mJSInterface , "JSBridge");            
        mWebView.loadUrl("file:///android_asset/index.html");
    }
    
    @Override
    protected void onDestroy() {
    	// TODO Auto-generated method stub
    	super.onDestroy();
    	unregisterReceiver(mApplicationsReceiver);
    }
    
    private class JSHomeWebViewClient extends WebViewClient{
    	@Override
    	public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
    		if(event.getAction() != KeyEvent.ACTION_DOWN){
    			return super.shouldOverrideKeyEvent(view, event);
    		}
    	   	switch (event.getKeyCode()) {
    		case KeyEvent.KEYCODE_DPAD_UP:
    			view.onKeyDown(KeyEvent.KEYCODE_W, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_W));
    			return true;
    			
    		case KeyEvent.KEYCODE_DPAD_DOWN:
    			view.onKeyDown(KeyEvent.KEYCODE_S, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_S));
    			return true;

    		case KeyEvent.KEYCODE_DPAD_LEFT:
    			view.onKeyDown(KeyEvent.KEYCODE_A, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_A));
    			return true;

    		case KeyEvent.KEYCODE_DPAD_RIGHT:
    			view.onKeyDown(KeyEvent.KEYCODE_D, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_D));
    			return true;
  
    		case KeyEvent.KEYCODE_DPAD_CENTER:
    			mWebView.onKeyDown(KeyEvent.KEYCODE_ENTER, new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
    			return true;    			
    		default:
    			return super.shouldOverrideKeyEvent(view, event);
    		}
    	}
    }
    
	/**
	 * Receives notifications when applications are added/removed
	 */
	private class ApplicationsIntentReceiver extends BroadcastReceiver {
		public void onReceive(Context context, Intent intent) {
			loadApplications(false);
			mJSInterface.updateApp();
		}
	}    

	private class JavaScriptInterface {
	    @SuppressWarnings("unused")
		Context mContext;
	    Handler mHandler;

	    /** Instantiate the interface and set the context */
	    JavaScriptInterface(Context c , Handler handler) {
	        mContext = c;
	        mHandler = handler;
	    }
	    
		private String encodeIcon(Drawable icon){
	        Drawable ic = icon;
	        if(ic !=null){
		        BitmapDrawable bitDw = ((BitmapDrawable) ic);
		        Bitmap bitmap = bitDw.getBitmap();
		        ByteArrayOutputStream stream = new ByteArrayOutputStream();
		        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream);
		        byte[] bitmapByte = stream.toByteArray();
//		        System.out.println("..length of image..."+bitmapByte.length);
//		        System.out.println("..image..."+Base64.encodeToString(bitmapByte, Base64.NO_WRAP));
		        return Base64.encodeToString(bitmapByte, Base64.NO_WRAP);
	        }
	        return "";
	}
	    
	    
		private String buildAppJson(){
			try {
				JSONArray jsonArray = new JSONArray();
				for(ApplicationInfo app:mApplications){
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("title", app.title);
					jsonObject.put("icon", encodeIcon(app.icon));
					jsonObject.put("intent", app.intent);
					jsonArray.put(jsonObject);
				}
				return jsonArray.toString();
			}catch (JSONException e){
				e.printStackTrace();
			}
			return null;
		}
	    
	    
	    public void updateApp(){
	    	mHandler.post(new Runnable() {  
                public void run() {  
                	mWebView.loadUrl("javascript:resetApplication('" + buildAppJson() + "')");	
                }  
            });  
	    }
	    
		@SuppressWarnings("unused")
		public void startApp(final String appname){
			if(mApplications != null ){
				ApplicationInfo app;
				for (int i = 0; i < mApplications.size(); i++) {
					app = (ApplicationInfo)mApplications.get(i);
					if( app.title.toString().equalsIgnoreCase(appname)){
						startActivity(app.intent);
						return;
					}
				}
			}
			startAppByDefinedTitle(appname);
	    }
		
		private void startAppByDefinedTitle(final String appname){
			
			Intent intent= new Intent();        
			
			
			if(appname.equalsIgnoreCase("视频")){
				intent.setAction(Intent.ACTION_GET_CONTENT);
				intent.setType("video/*");
				startActivity(intent);	
				return;
			}
			if(appname.equalsIgnoreCase("音频")){
				intent.setAction(MediaStore.INTENT_ACTION_MUSIC_PLAYER);
				startActivity(intent);					
				return;
			}	
			if(appname.equalsIgnoreCase("图片")){
				intent.setAction(Intent.ACTION_GET_CONTENT);
				intent.setType("image/*");
				startActivity(intent);	
				return;
			}
			if(appname.equalsIgnoreCase("浏览器")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.baidu.com/");   
				intent.setData(content_url);           
				startActivity(intent);				
				return;
			}
			if(appname.equalsIgnoreCase("优库")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.youku.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("土豆")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.tudou.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("酷6")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.ku6.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("56网")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.56.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("爱奇艺")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.iqiyi.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("乐视网")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.letv.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}			
			if(appname.equalsIgnoreCase("激动网")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://www.joy.cn/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("新浪视频")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://video.sina.com.cn/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("搜狐视频")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://tv.sohu.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("网易视频")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://v.163.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("凤凰视频")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://v.ifeng.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}
			if(appname.equalsIgnoreCase("腾讯视频")){
				intent.setAction(Intent.ACTION_VIEW); 
				Uri content_url = Uri.parse("http://v.qq.com/");   
				intent.setData(content_url);           
				startActivity(intent);
				return;
			}			
			
			if(appname.equalsIgnoreCase("设置")){
				intent.setAction(Settings.ACTION_SETTINGS);
				startActivity(intent);
				return;
			}
		}
	 
	}
	
	private void registerIntentReceivers() {
		IntentFilter filter = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
		filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
		filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
		filter.addDataScheme("package");
		registerReceiver(mApplicationsReceiver, filter);
	}
    
	/**
	 * Loads the list of installed applications in mApplications.
	 */
	private void loadApplications(boolean isLaunching) {
		if (isLaunching && mApplications != null) {
			return;
		}
		
		PackageManager manager = getPackageManager();
		
		Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
		mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		
		final List<ResolveInfo> apps = manager.queryIntentActivities(mainIntent, 0);
		Collections.sort(apps, new ResolveInfo.DisplayNameComparator(manager));
		
		if (apps != null) {
			final int count = apps.size();
			
			if (mApplications == null) {
				mApplications = new ArrayList<ApplicationInfo>(count);
			}
			mApplications.clear();
			
			for (int i = 0; i < count; i++) {
				ApplicationInfo application = new ApplicationInfo();
				ResolveInfo info = apps.get(i);
				
				application.title = info.loadLabel(manager);
				application.setActivity(new ComponentName(
						info.activityInfo.applicationInfo.packageName,
						info.activityInfo.name),
						Intent.FLAG_ACTIVITY_NEW_TASK
						| Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
				application.icon = info.activityInfo.loadIcon(manager);
				
				mApplications.add(application);
			}
		}
	}
}